import axios from "axios";

export default axios.create({
  baseURL: "http://3.38.99.84:4000/",
})