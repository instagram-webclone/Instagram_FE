import blackcompass from "../image/icon/blackcompass.png";
import blackhome from "../image/icon/blackhome.png";
import blackmessage from "../image/icon/blackmessage.png";
import blackwrite from "../image/icon/blackwrite.png";
import compass from "../image/icon/compass.png";
import home from "../image/icon/home.png";
import hovermark from "../image/icon/hovermark.png";
import hovertext from "../image/icon/hovertext.png";
import mark from "../image/icon/mark.png";
import message from "../image/icon/message.png";
import text from "../image/icon/text.png";
import write from "../image/icon/write.png"
import heart from "../image/icon/heart.png";
import post_save from "../image/icon/post_save.png";
import post_saveActive from "../image/icon/post_saveActive.png";
import blackheart from "../image/icon/blackheart.png"
import menu_change from "../image/icon/menu_change.png";
import menu_profile from "../image/icon/menu_profile.png";
import menu_save from "../image/icon/menu_save.png";
import menu_setting from "../image/icon/menu_setting.png";
import dot from "../image/icon/dot.png";
import recomtest from "../image/recomtest.png"
import my_message from "../image/my_message.png";
import emoji from "../image/icon/emoji.png";
import comment_heart from "../image/icon/comment_heart.png";
import comment_red_heart from "../image/icon/comment_red_heart.png";
import post_heart from "../image/icon/post_heart.png";
import post_red_heart from "../image/icon/post_red_heart.png";
import x_img from "../image/icon/x_img.png";
import profile_setting from "../image/icon/profile_setting.png";
import none_profile from "../image/profile.png";
import hash_icon from "../image/icon/hashIcon.png";
import bubble from "../image/icon/recom_bubble.png";
import recom_heart from "../image/icon/recom_heart.png";


export {blackcompass, blackhome, blackmessage, blackwrite, x_img, none_profile, hash_icon,
  compass, home, hovermark, hovertext, mark, message, text, my_message,bubble, recom_heart,
  heart, write, post_saveActive, post_save, blackheart, menu_save, menu_setting, menu_change,
  menu_profile, dot, recomtest, emoji, comment_heart, comment_red_heart, post_red_heart, post_heart, profile_setting};