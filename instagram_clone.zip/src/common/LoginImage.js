import login_pic1 from "../image/loginimage/login_pic1.png";
import login_pic2 from "../image/loginimage/login_pic2.jpg";
import login_pic3 from "../image/loginimage/login_pic3.jpg";
import login_pic4 from "../image/loginimage/login_pic4.jpg";
import login_pic5 from "../image/loginimage/login_pic5.jpg";
import login_pic6 from "../image/loginimage/login_pic6.jpg";
import download1 from "../image/loginimage/download1.png";
import download2 from "../image/loginimage/download2.png";
import instagramlogo from "../image/loginimage/instagramlogo.png";
import facebook from "../image/loginimage/facebook.png";
import facebook_white from "../image/loginimage/facebook_white.png";
import lock from "../image/loginimage/lock.png";

export {
	login_pic1,
	login_pic2,
	login_pic3,
	login_pic4,
	login_pic5,
	login_pic6,
	download1,
	download2,
	instagramlogo,
	facebook,
	facebook_white,
	lock,
};
