import React from "react";

import { recomtest } from "../../../../common/IconImage";

const ProfileTagged = () => {
	return (
		<>
			<div className="otherProfile_postList">
				<div className="otherProfile_post">
					<img src={recomtest} />
				</div>
				<div className="otherProfile_post">
					<img src={recomtest} />
				</div>
				<div className="otherProfile_post">
					<img src={recomtest} />
				</div>
				{/* <div className="otherProfile_post">
					<img src={recomtest} />
				</div>
				<div className="otherProfile_post">
					<img src={recomtest} />
				</div>
				<div className="otherProfile_post">
					<img src={recomtest} />
				</div> */}
			</div>
		</>
	);
};

export default ProfileTagged;
