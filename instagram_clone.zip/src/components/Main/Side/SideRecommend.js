import profile from "../../../image/profile.png";
import "./SideMain.scss";

const SideRecommend = () => {

  return(
    <>
      <div className="follow_recommend">
        <div className="recommend_profile">
          <img src={profile}/>
        </div>
        <div>
          <div className="follow_recommend_id">lisaccojewelry</div>
          <div className="follow_recommend_text">sihuni_200414님이 팔로우합니다</div>
        </div>
        <a className="recommend_follow">팔로우</a>
      </div>
      <div className="follow_recommend">
        <div className="recommend_profile">
          <img src={profile}/>
        </div>
        <div>
          <div className="follow_recommend_id">lisaccojewelry</div>
          <div className="follow_recommend_text">sihuni_200414님이 팔로우합니다</div>
        </div>
        <a className="recommend_follow">팔로우</a>
      </div>
      <div className="follow_recommend">
        <div className="recommend_profile">
          <img src={profile}/>
        </div>
        <div>
          <div className="follow_recommend_id">lisaccojewelry</div>
          <div className="follow_recommend_text">sihuni_200414님이 팔로우합니다</div>
        </div>
        <a className="recommend_follow">팔로우</a>
      </div>
      <div className="follow_recommend">
        <div className="recommend_profile">
          <img src={profile}/>
        </div>
        <div>
          <div className="follow_recommend_id">lisaccojewelry</div>
          <div className="follow_recommend_text">sihuni_200414님이 팔로우합니다</div>
        </div>
        <a className="recommend_follow">팔로우</a>
      </div>
      <div className="follow_recommend">
        <div className="recommend_profile">
          <img src={profile}/>
        </div>
        <div>
          <div className="follow_recommend_id">lisaccojewelry</div>
          <div className="follow_recommend_text">sihuni_200414님이 팔로우합니다</div>
        </div>
        <a className="recommend_follow">팔로우</a>
      </div>
    </>
  )
}
export default SideRecommend;
