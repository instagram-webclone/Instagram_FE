import { createBrowserHistory } from 'history'
import React  from "react";


export const history = createBrowserHistory();

